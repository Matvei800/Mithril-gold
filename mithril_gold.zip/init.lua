minetest.register_craftitem("mithril_gold:ingot", {
    description = "Mithril gold ingot",
    inventory_image = "mithril_gold_ingot.png"
})

minetest.register_craftitem("mithril_gold:lump", {
    description = "Mithril gold lump",
    inventory_image = "mithril_gold_lump.png"
})

minetest.register_node("mithril_gold:block", {
	description = ("Mithril gold block"),
	tiles = {"mithril_gold_block.png"},
	is_ground_content = false,
	groups = {cracky = 1, level = 2},
	sounds = default.node_sound_metal_defaults(),
})

minetest.register_node("mithril_gold:ore", {
	description = ("Mithril gold ore"),
	tiles = {"default_stone.png^mithril_gold_mineral.png"},
	groups = {cracky = 1},
	drop = "mithril_gold:lump",
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_tool("mithril_gold:pickaxe", {
	description = ("Mithril gold pickaxe"),
	inventory_image = "mithril_gold_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=3,
		groupcaps={
			cracky = {times={[1]=1.5, [2]=0.5, [3]=0.45}, uses=205, maxlevel=3},
		},
		damage_groups = {fleshy=5},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1}
})

minetest.register_tool("mithril_gold:shovel", {
	description = ("Mithril gold shovel"),
	inventory_image = "mithril_gold_shovel.png",
	wield_image = "mithril_gold_shovel.png^[transformR90",
	tool_capabilities = {
		full_punch_interval = 0.9,
		max_drop_level=1,
		groupcaps={
			crumbly = {times={[1]=1.05, [2]=0.45, [3]=0.15}, uses=205, maxlevel=3},
		},
		damage_groups = {fleshy=4},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {shovel = 1}
})

minetest.register_tool("mithril_gold:axe", {
	description = ("Mithril gold axe"),
	inventory_image = "mithril_gold_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=2.05, [2]=0.85, [3]=0.45}, uses=205, maxlevel=3},
		},
		damage_groups = {fleshy=7},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1}
})

minetest.register_tool("mithril_gold:sword", {
	description = ("Mithril gold sword"),
	inventory_image = "mithril_gold_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level=1,
		groupcaps={
			snappy={times={[1]=1.85, [2]=0.85, [3]=0.25}, uses=205, maxlevel=3},
		},
		damage_groups = {fleshy=8},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {sword = 1}
})

---crafting

minetest.register_craft({
    output = "mithril_gold:block ",
    recipe = {
        {"mithril_gold:ingot", "mithril_gold:ingot",  "mithril_gold:ingot"},
        {"mithril_gold:ingot", "mithril_gold:ingot",  "mithril_gold:ingot"},
        {"mithril_gold:ingot", "mithril_gold:ingot",  "mithril_gold:ingot"}
    }
})

minetest.register_craft({
	output = 'mithril_gold:ingot 9 ',
	recipe = {
		{'', '', ''},
		{'', 'mithril_gold:block', ''},
		{'', '', ''},
	}
})


minetest.register_craft({
    type = "cooking",
    output = "mithril_gold:ingot",
    recipe = "mithril_gold:lump",
    cooktime = 10,
})

minetest.register_craft({
	output = 'mithril_gold:pickaxe',
	recipe = {
		{'mithril_gold:ingot', 'mithril_gold:ingot', 'mithril_gold:ingot'},
		{'', 'default:stick', ''},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'mithril_gold:axe',
	recipe = {
		{'mithril_gold:ingot', 'mithril_gold:ingot', ''},
		{'mithril_gold:ingot', 'default:stick', ''},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'mithril_gold:shovel',
	recipe = {
		{'', 'mithril_gold:ingot', ''},
		{'', 'default:stick', ''},
		{'', 'default:stick', ''},
	}
})

minetest.register_craft({
	output = 'mithril_gold:sword',
	recipe = {
		{'', 'mithril_gold:ingot', ''},
		{'', 'mithril_gold:ingot', ''},
		{'', 'default:stick', ''},
	}
})

---ore

minetest.register_ore({
		ore_type       = "scatter",
		ore            = "mithril_gold:ore",
		wherein        = "default:stone",
		clust_scarcity = 26 * 26 * 26,
		clust_num_ores = 6,
		clust_size     = 5,
		y_min          = -31000,
		y_max          = -2500,
	})